(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var SpacebarsCompiler = Package['spacebars-compiler'].SpacebarsCompiler;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['carlosbaraza:accounts-ui-bootstrap-3-angular'] = {};

})();
